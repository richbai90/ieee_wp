<div class="wrap">
    <div class="container">
        <?php fundor_render_footer(); ?>
    </div>
</div>