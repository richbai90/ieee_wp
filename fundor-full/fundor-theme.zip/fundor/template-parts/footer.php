<div class="site-info py-3">
    <div class="container">
        <?php echo  wp_kses_post(get_theme_mod( 'osf_footer_copyright_left', esc_html__('Proudly powered by Themelexus.com','fundor') )) ; ?>
    </div>
</div><!-- .site-info -->
